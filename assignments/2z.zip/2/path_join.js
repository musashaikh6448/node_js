//The path.join() method joins the specified path segments into one path.
let path = require("path");

let x = path.join("/class", "Day5/filesystem1.js");
console.log(x);



