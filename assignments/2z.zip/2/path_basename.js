let path=require('path');

let data=path.basename('node.js/class/Day5/filesystem.js')
console.log(`this is base name of this path________________ ${data}`);
