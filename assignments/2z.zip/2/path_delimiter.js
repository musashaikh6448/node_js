let path=require('path');
console.log(path.delimiter);
