let path=require('path');

let directory=path.dirname('node.js/class/Day5/filesystem1.js')
console.log(directory);
