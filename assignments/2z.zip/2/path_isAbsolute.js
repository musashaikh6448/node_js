//The path.isAbsolute() method returns true if the specified path is an absolute path, otherwise false.

let path = require("path");
console.log(path.isAbsolute("/class/Day5/filesystem1.js"));

console.log(path.isAbsolute("node.js/class/Day5/filesystem1.js"));

