// The path.extname() method returns the extension of a file path.

let path=require('path');

let extension=path.extname('node.js/class/Day5/filesystem1.js')
console.log(extension);
