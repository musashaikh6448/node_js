//Q20)write a program which create file with your name

const fs=require('fs')

fs.writeFileSync('shaikhmusa.txt','hii')
