//Q9)write a node js program for finding Platform of your machine

const os = require('os')


console.log(os.platform());
