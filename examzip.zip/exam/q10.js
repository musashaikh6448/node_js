//Q10)write a node js program for finding Architecture of your machine

const os =require('os')

console.log(os.arch());
